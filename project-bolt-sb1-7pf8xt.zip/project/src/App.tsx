import React from 'react';
import LoginForm from './components/LoginForm';

function App() {
  return <LoginForm />;
}

export default App;